# LRI Mortality in West Africa: Machine Learning Analysis

## Overview
This repository contains the complete code and data for the study:
*"Temporal Trends and Mortality Burden of Lower Respiratory Infections in West African Countries (2010–2023): A Global Burden of Disease Analysis"*

## Key analyses
- K‑means clustering of mortality trajectories (16 countries, 2010‑2023)
- XGBoost with SHAP for driver importance (stunting, clean fuels, HIV, PM2.5, smoking, DTP3)
- Temporal SHAP and immune arm transition (innate vs. adaptive immunity)
- COVID‑19 counterfactual (excess mortality 2020‑2023)
- Ensemble forecasting (Prophet, XGBoost, LightGBM, LSTM) to 2030
- Policy inaction cost (excess ASMR vs. best performer)

## Repository structure
```
west-africa-lri-ml/
├── data/                     # Processed dataset
├── scripts/                  # Analysis scripts (01–06)
├── results/                  # Output CSV tables
├── figures/                  # Publication‑ready figures
├── requirements.txt          # Python dependencies
├── LICENSE                   # MIT license
└── README.md                 # This file
```

## Getting started
```bash
git clone https://github.com/yourusername/west-africa-lri-ml.git
cd west-africa-lri-ml
pip install -r requirements.txt
python scripts/01_data_processing.py
# ... run other scripts in order
```

## Citation
When using this code, please cite the original publication (to be added).

## License
MIT
