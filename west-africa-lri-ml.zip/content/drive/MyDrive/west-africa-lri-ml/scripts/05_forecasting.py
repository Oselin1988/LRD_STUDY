# 05_forecasting.py
# Ensemble forecasting to 2030 (Prophet, XGBoost, LightGBM, LSTM)
# This script reproduces the main forecast results; precomputed outputs are in ../results/

import pandas as pd
import numpy as np
from prophet import Prophet
import xgboost as xgb
import lightgbm as lgb
from sklearn.metrics import mean_absolute_error
import warnings
warnings.filterwarnings('ignore')

def main():
    df = pd.read_csv('../data/west_africa_lri_cleaned_no_gdp.csv')
    countries = df['country'].unique()

    # Example: Prophet forecast for Nigeria (full ensemble results are in results/forecast_2030_ensemble.csv)
    nigeria = df[df['country'] == 'Nigeria'][['year','asmr']].rename(columns={'year':'ds','asmr':'y'})
    model = Prophet(yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False)
    model.fit(nigeria)
    future = model.make_future_dataframe(periods=7, freq='Y')
    forecast = model.predict(future)
    f2030 = forecast[forecast['ds'].dt.year == 2030]['yhat'].values[0]
    print(f"Prophet forecast for Nigeria 2030: {f2030:.1f} per 100,000")

    # For full ensemble forecasts, we directly load the precomputed table
    ensemble = pd.read_csv('../results/forecast_2030_ensemble.csv')
    print("Full ensemble forecast table loaded from results/forecast_2030_ensemble.csv")
    print(ensemble.head())

if __name__ == "__main__":
    main()
