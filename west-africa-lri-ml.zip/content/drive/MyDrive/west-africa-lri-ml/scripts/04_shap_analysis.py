# 04_shap_analysis.py
# Global SHAP, temporal SHAP, and immune arm transition

import pandas as pd
import numpy as np
import xgboost as xgb
import shap
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

def main():
    df = pd.read_csv('../data/west_africa_lri_cleaned_no_gdp.csv')
    predictors = ['pm25','smoking','dtp3','clean_fuels','stunting','hiv']
    target = 'asmr'

    # Train on pre‑2020 data (for temporal analysis)
    train = df[df['year'] <= 2019]
    X_train, y_train = train[predictors], train[target]

    model = xgb.XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=4, random_state=42)
    model.fit(X_train, y_train)

    # Global SHAP on test set (2022‑2023)
    test = df[df['year'] >= 2022]
    X_test = test[predictors]
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test)
    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    print("Global mean |SHAP|:")
    for p, v in zip(predictors, mean_abs_shap):
        print(f"  {p}: {v:.4f}")

    # Temporal SHAP (2010‑2023)
    years = sorted(df['year'].unique())
    importance_over_time = {f: [] for f in predictors}
    model_temp = xgb.XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=4, random_state=42)
    model_temp.fit(X_train, y_train)
    explainer_temp = shap.TreeExplainer(model_temp)

    for yr in years:
        X_yr = df[df['year'] == yr][predictors]
        if len(X_yr) > 0:
            shap_yr = explainer_temp.shap_values(X_yr)
            mean_abs_yr = np.abs(shap_yr).mean(axis=0)
            for i,f in enumerate(predictors):
                importance_over_time[f].append(mean_abs_yr[i])
    temporal_df = pd.DataFrame(importance_over_time, index=years)
    temporal_df.to_csv('../results/temporal_shap.csv')
    print("Temporal SHAP saved.")

    # Immune arm transition
    immune_arms = {
        'Innate (Air pollution)': ['pm25','clean_fuels'],
        'Adaptive (Vaccine/Nutrition)': ['dtp3','stunting'],
        'Behavioral/Other': ['smoking','hiv']
    }
    immune_importance = {arm: [] for arm in immune_arms}
    for i, yr in enumerate(years):
        for arm, feats in immune_arms.items():
            total = sum(importance_over_time[f][i] for f in feats)
            immune_importance[arm].append(total)
    immune_df = pd.DataFrame(immune_importance, index=years)
    immune_df.to_csv('../results/immune_arm_transition.csv')
    print("Immune arm transition saved.")

if __name__ == "__main__":
    main()
