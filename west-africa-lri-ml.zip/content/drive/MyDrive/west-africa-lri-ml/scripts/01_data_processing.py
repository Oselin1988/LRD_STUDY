# 01_data_processing.py
# Full data processing pipeline: load raw GBD data, fetch external predictors,
# clean, impute missing values, and save final dataset.

import pandas as pd
import numpy as np
import wbdata
import os
import re

def load_raw_gbd(folder_path='/content/'):
    """Combine yearly DATA Excel files into one master dataframe."""
    file_list = [f for f in os.listdir(folder_path) if f.startswith('DATA') and (f.endswith('.xls') or f.endswith('.xlsx'))]
    def extract_year(filename):
        match = re.search(r'(201[0-9]|202[0-3])', filename)
        return int(match.group(0)) if match else None
    df_list = []
    for filename in file_list:
        year = extract_year(filename)
        if year is None:
            continue
        filepath = os.path.join(folder_path, filename)
        if filename.endswith('.xlsx'):
            df = pd.read_excel(filepath, engine='openpyxl')
        else:
            df = pd.read_excel(filepath, engine='xlrd')
        df['year'] = year
        df_list.append(df)
    return pd.concat(df_list, ignore_index=True)

def filter_west_africa(df):
    west_africa = ['Benin','Burkina Faso','Cabo Verde',"Côte d'Ivoire",'Gambia','Ghana',
                   'Guinea','Guinea-Bissau','Liberia','Mali','Mauritania','Niger',
                   'Nigeria','Senegal','Sierra Leone','Togo']
    return df[df['location_name'].isin(west_africa)]

def create_asmr(df):
    asmr = df[(df['measure_name']=='Deaths') & (df['metric_name']=='Rate')]
    asmr_agg = asmr.groupby(['location_name','year'])['val'].mean().reset_index()
    asmr_agg.rename(columns={'location_name':'country','val':'asmr'}, inplace=True)
    return asmr_agg

def fetch_wb_indicator(indicator_code, country_iso3_map, indicator_name):
    data_list = []
    for country_name, iso3 in country_iso3_map.items():
        try:
            data = wbdata.get_dataframe({indicator_code: indicator_name}, country=iso3)
            data = data.reset_index()
            if 'date' not in data.columns:
                data.rename(columns={'index':'date'}, inplace=True)
            data['year'] = pd.to_numeric(data['date'], errors='coerce')
            data = data.dropna(subset=['year'])
            data = data[data['year'].between(2010,2023)]
            data['country'] = country_name
            data_list.append(data[['country','year',indicator_name]])
        except:
            pass
    if data_list:
        return pd.concat(data_list, ignore_index=True)
    else:
        return pd.DataFrame(columns=['country','year',indicator_name])

def main():
    # 1. Load and prepare raw GBD ASMR
    raw = load_raw_gbd()
    west = filter_west_africa(raw)
    asmr = create_asmr(west)
    print(f"ASMR shape: {asmr.shape}")

    # 2. External predictors (World Bank)
    country_iso3 = {
        'Benin':'BEN','Burkina Faso':'BFA','Cabo Verde':'CPV',"Côte d'Ivoire":'CIV',
        'Gambia':'GMB','Ghana':'GHA','Guinea':'GIN','Guinea-Bissau':'GNB','Liberia':'LBR',
        'Mali':'MLI','Mauritania':'MRT','Niger':'NER','Nigeria':'NGA','Senegal':'SEN',
        'Sierra Leone':'SLE','Togo':'TGO'
    }
    predictors = {
        'gdp': 'NY.GDP.PCAP.KD',
        'pm25': 'EN.ATM.PM25.MC.M3',
        'dtp3': 'SH.IMM.IDPT',
        'clean_fuels': 'EG.CFT.ACCS.ZS',
        'stunting': 'SH.STA.STNT.ZS',
        'hiv': 'SH.DYN.AIDS.ZS'
    }
    # Smoking from OWID (manual download explained in README)
    # For reproducibility, we include a placeholder – user must download smoking CSV.
    # Here we assume the final cleaned CSV is provided directly.

    # Merge all predictors
    merged = asmr.copy()
    for short, code in predictors.items():
        print(f"Fetching {short}...")
        df_pred = fetch_wb_indicator(code, country_iso3, short)
        merged = merged.merge(df_pred, on=['country','year'], how='left')
        # Interpolate missing values
        merged[short] = merged.groupby('country')[short].transform(lambda x: x.interpolate(method='linear', limit_direction='both'))
        yearly_avg = merged[merged[short].notna()].groupby('year')[short].transform('mean')
        merged[short] = merged[short].fillna(yearly_avg)
        merged[short] = merged[short].fillna(merged[short].mean())

    # Drop GDP (collinearity) and keep final six predictors
    final = merged.drop(columns=['gdp'])
    # Save
    final.to_csv('../data/west_africa_lri_cleaned_no_gdp.csv', index=False)
    print("Saved final dataset to ../data/west_africa_lri_cleaned_no_gdp.csv")

if __name__ == "__main__":
    main()
