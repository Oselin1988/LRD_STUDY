# 02_clustering_analysis.py
# K-means clustering of LRI mortality trajectories (16 countries, 2010-2023)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

def main():
    # Load cleaned data
    df = pd.read_csv('../data/west_africa_lri_cleaned_no_gdp.csv')
    predictors = ['pm25','smoking','dtp3','clean_fuels','stunting','hiv']
    target = 'asmr'

    # Create pivot matrix (countries × years)
    pivot = df.pivot(index='country', columns='year', values='asmr')
    scaler = StandardScaler()
    scaled = scaler.fit_transform(pivot)

    # Find optimal k (2-6)
    inertias = []
    sil_scores = []
    k_range = range(2,7)
    for k in k_range:
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        km.fit(scaled)
        inertias.append(km.inertia_)
        sil_scores.append(silhouette_score(scaled, km.labels_))

    optimal_k = sil_scores.index(max(sil_scores)) + 2
    print(f"Optimal k = {optimal_k}")

    # Final clustering
    km = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
    clusters = km.fit_predict(scaled)
    cluster_map = dict(zip(pivot.index, clusters))
    df['cluster'] = df['country'].map(cluster_map)

    # Save clustering results
    df.to_csv('../results/clustering_results.csv', index=False)

    # Cluster composition
    for c in range(optimal_k):
        countries = df[df['cluster']==c]['country'].unique()
        print(f"Cluster {c}: {len(countries)} countries - {', '.join(countries)}")

    # Generate Figure 1 (clustering panel) – saved in ../figures/
    # (Full plotting code omitted for brevity; the final figures are already in the repo.)
    print("Clustering analysis completed. Results saved.")

if __name__ == "__main__":
    main()
