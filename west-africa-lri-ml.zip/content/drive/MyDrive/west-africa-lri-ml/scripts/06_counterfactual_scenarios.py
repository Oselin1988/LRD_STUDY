# 06_counterfactual_scenarios.py
# COVID‑19 counterfactual (2020‑2023) and 20% PM2.5 reduction scenario

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.metrics import mean_absolute_error
import warnings
warnings.filterwarnings('ignore')

def main():
    df = pd.read_csv('../data/west_africa_lri_cleaned_no_gdp.csv')
    predictors = ['pm25','smoking','dtp3','clean_fuels','stunting','hiv']
    target = 'asmr'

    # Train on pre‑COVID (2010‑2019)
    train = df[df['year'] <= 2019]
    X_train, y_train = train[predictors], train[target]
    model = xgb.XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=4, random_state=42)
    model.fit(X_train, y_train)

    # COVID counterfactual (2020‑2023)
    covid_years = [2020,2021,2022,2023]
    observed = []
    forecasted = []
    for yr in covid_years:
        X_yr = df[df['year'] == yr][predictors]
        observed.append(df[df['year'] == yr][target].mean())
        forecasted.append(model.predict(X_yr).mean())
    excess = [o - f for o, f in zip(observed, forecasted)]
    print("COVID counterfactual excess ASMR (observed - forecast):")
    for yr, exc in zip(covid_years, excess):
        print(f"  {yr}: {exc:.2f} per 100,000")
    # Save results
    covid_df = pd.DataFrame({'year':covid_years, 'observed':observed, 'forecast':forecasted, 'excess':excess})
    covid_df.to_csv('../results/covid_counterfactual_results.csv', index=False)

    # 20% PM2.5 reduction scenario (2022‑2023)
    test = df[df['year'] >= 2022]
    X_test = test[predictors].copy()
    baseline = model.predict(X_test)
    X_test['pm25'] = X_test['pm25'] * 0.8
    scenario = model.predict(X_test)
    reduction = baseline - scenario
    avg_reduction = reduction.mean()
    print(f"\n20% PM2.5 reduction → ASMR reduction: {avg_reduction:.2f} per 100,000")
    scenario_df = test[['country','year']].copy()
    scenario_df['baseline'] = baseline
    scenario_df['counterfactual'] = scenario
    scenario_df['reduction'] = reduction
    scenario_df.to_csv('../results/scenario_results.csv', index=False)

if __name__ == "__main__":
    main()
