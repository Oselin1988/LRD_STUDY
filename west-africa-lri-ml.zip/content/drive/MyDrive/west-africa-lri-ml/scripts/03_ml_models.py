# 03_ml_models.py
# Train and evaluate Linear Regression, Random Forest, XGBoost

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')

def main():
    df = pd.read_csv('../data/west_africa_lri_cleaned_no_gdp.csv')
    predictors = ['pm25','smoking','dtp3','clean_fuels','stunting','hiv']
    target = 'asmr'

    # Time‑based split
    train = df[df['year'] <= 2019]
    val = df[df['year'].isin([2020,2021])]
    test = df[df['year'].isin([2022,2023])]

    X_train, y_train = train[predictors], train[target]
    X_val, y_val = val[predictors], val[target]
    X_test, y_test = test[predictors], test[target]

    # Linear Regression
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_pred_lr = lr.predict(X_test)
    mae_lr = mean_absolute_error(y_test, y_pred_lr)
    rmse_lr = np.sqrt(mean_squared_error(y_test, y_pred_lr))
    r2_lr = r2_score(y_test, y_pred_lr)
    print(f"Linear Regression: MAE={mae_lr:.2f}, RMSE={rmse_lr:.2f}, R2={r2_lr:.3f}")

    # Random Forest
    rf = RandomForestRegressor(n_estimators=100, max_depth=5, random_state=42)
    rf.fit(X_train, y_train)
    y_pred_rf = rf.predict(X_test)
    mae_rf = mean_absolute_error(y_test, y_pred_rf)
    rmse_rf = np.sqrt(mean_squared_error(y_test, y_pred_rf))
    r2_rf = r2_score(y_test, y_pred_rf)
    print(f"Random Forest: MAE={mae_rf:.2f}, RMSE={rmse_rf:.2f}, R2={r2_rf:.3f}")

    # XGBoost
    xgb_model = xgb.XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=4,
                                 random_state=42, early_stopping_rounds=10, eval_metric='rmse')
    xgb_model.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=False)
    y_pred_xgb = xgb_model.predict(X_test)
    mae_xgb = mean_absolute_error(y_test, y_pred_xgb)
    rmse_xgb = np.sqrt(mean_squared_error(y_test, y_pred_xgb))
    r2_xgb = r2_score(y_test, y_pred_xgb)
    print(f"XGBoost: MAE={mae_xgb:.2f}, RMSE={rmse_xgb:.2f}, R2={r2_xgb:.3f}")

    # Save comparison
    comparison = pd.DataFrame({
        'Model': ['Linear Regression','Random Forest','XGBoost'],
        'MAE': [mae_lr, mae_rf, mae_xgb],
        'RMSE': [rmse_lr, rmse_rf, rmse_xgb],
        'R2': [r2_lr, r2_rf, r2_xgb]
    })
    comparison.to_csv('../results/model_comparison_complete.csv', index=False)
    print("Model comparison saved to results/model_comparison_complete.csv")

if __name__ == "__main__":
    main()
